﻿

//Console.WriteLine("Hello and Welcome to Programming world");

//Console.WriteLine("This is second line");


using bankingAPP;
using bankingAPP.AccountTypes;

bool dotransaction = true;
//Accounts accObj = new Accounts("Blank Account", "NA", 1000); // new object of accounts should not be created
bankingAPP.Employee accObj = null;




while (dotransaction)
{
    Console.WriteLine("~~~~~~~~~~~~~~~~ Welcome to Employee Management System ~~~~~~~~~~~~~");

    Console.WriteLine("Press Enter To Continue");
    Console.ReadLine();
    Console.Clear();


    Console.WriteLine("1. Employee");
    Console.WriteLine("2. HR");
    Console.WriteLine("3. Exit");
    

    int userChoice = Convert.ToInt32(Console.ReadLine());


    switch (userChoice)
    {
        #region Employee
        case 1:

            Console.Clear();
            Console.WriteLine("1. View My Details");
            Console.WriteLine("2. Apply For Leave");
            Console.WriteLine("3. Exit");


            int userData = Convert.ToInt32(Console.ReadLine());

            switch(userData)
            {

                case 1:
                    Console.WriteLine("Employee ID: " + accObj.EmployeeId);
                    Console.WriteLine("Employee Name: " + accObj.EmployeeName);
                    Console.WriteLine("Employee Salary: " + accObj.EmployeeSalary);
                    Console.WriteLine("Employee Leave Balance: " + accObj.LeaveBalance);
                    break;
                case 2:
                    Console.WriteLine("Enter No of Days");
                    int leavedays = Convert.ToInt32(Console.ReadLine());
                    accObj.ApproveLeaves(leavedays);
                    if (accObj.EmployeeType == "Accounts")
                    {
                        if (leavedays <= 8)
                        {
                            Console.WriteLine("Leaves Approved Successfully,Leave Balance is " + accObj.LeaveBalance);
                        }
                        
                    }
                    else if (accObj.EmployeeType == "Developer")
                    {
                        if (leavedays <= 12)
                        {
                            Console.WriteLine("Leaves Approved Successfully,Leave Balance is " + accObj.LeaveBalance);
                        }
                       
                    }
                    else if (accObj.EmployeeType == "Manager")
                    {
                        if (leavedays <= 10)
                        {
                            Console.WriteLine("Leaves Approved Successfully,Leave Balance is " + accObj.LeaveBalance);

                        }
                        
                    
                    }

                    break;
                case 3:
                    break;
                default:
                    break;

            }

            //Console.WriteLine("Enter Account Number");
            //accObj.AccountNo = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Enter Account Name");
            //accObj.AccountName = Console.ReadLine();
            //Console.WriteLine("Enter Account Type");
            //accObj.AccountType =  Console.ReadLine();
            //Console.WriteLine("Enter Account Balance");
            //accObj.AccountBalance = Convert.ToDouble(Console.ReadLine());

            //Console.WriteLine("Account Created Successfully, Account No is : " + accObj.AccountNo);

            //bydefault we keep account as Active

            break;
        #endregion

        #region HR
        case 2:
            Console.Clear();
            Console.WriteLine("1. Add New Employee");
            Console.WriteLine("2. Approve Leaves");
            Console.WriteLine("3. Appraise Employee");
            Console.WriteLine("4. Edit Employee");
            Console.WriteLine("5. View Employee");
            int userOption = Convert.ToInt32(Console.ReadLine());

            switch (userOption)
            {
                case 1:
                    Console.WriteLine("1. Accounts");
                    Console.WriteLine("2. Developer");
                    Console.WriteLine("2. Manager");
                    

                    int empTypeOption= Convert.ToInt32(Console.ReadLine());

                    switch (empTypeOption)
                    {
                        case 1:
                            accObj = new bankingAPP.AccountTypes.Accounts("Blank Name", "Blank Type", 0, 0);

                            Console.WriteLine("Enter Employee Name");
                            accObj.EmployeeName = Convert.ToString(Console.ReadLine());
                            accObj.EmployeeType = "Accounts";
                            Console.WriteLine("Enter Employee Salary");
                            accObj.EmployeeSalary = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter Employee Leave Balance");
                            accObj.LeaveBalance = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Employee Created Successfully with Emp Id:"+accObj.EmployeeId);

                            break;

                        case 2:
                            accObj = new Accounts("Blank Name", "Blank Type", 0, 0);

                            Console.WriteLine("Enter Employee Name");
                            accObj.EmployeeName = Convert.ToString(Console.ReadLine());
                            accObj.EmployeeType = "Developer";
                            Console.WriteLine("Enter Employee Salary");
                            accObj.EmployeeSalary = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter Employee Leave Balance");
                            accObj.LeaveBalance = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Employee Created Successfully with Emp Id:" + accObj.EmployeeId);
                            break;


                        case 3:

                            accObj = new Manager("Blank Name", "Blank Type", 0, 0);

                            Console.WriteLine("Enter Employee Name");
                            accObj.EmployeeName = Convert.ToString(Console.ReadLine());
                            accObj.EmployeeType = "Manager";
                            Console.WriteLine("Enter Employee Salary");
                            accObj.EmployeeSalary = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter Employee Leave Balance");
                            accObj.LeaveBalance = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Employee Created Successfully with Emp Id:" + accObj.EmployeeId);
                            break;


                        default:
                            break;

                            
                    }

                    break;
              
                default:
                    break;
            
                        
            }

            break;
        #endregion

        case 3:
            Console.WriteLine("Thank you, see you soon again ");
            dotransaction = false;
            break;
        default:
            Console.WriteLine("Sorry invalid option ");
            break;       

           
    }

}




