﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingAPP.AccountTypes
{
    internal class Accounts : Employee
    {

        static int auto_employeeid = 500;
        public Accounts(string p_name, string p_type, double p_salary,double p_leavebalance):base(p_name,p_type,p_salary,p_leavebalance)
        {
            auto_employeeid = auto_employeeid + 1;
            EmployeeId = auto_employeeid;
        }

        public override double ApproveLeaves(int p_leavesdays)
        {
            if (p_leavesdays > 8)
            {
                //throw new exception
                Console.WriteLine("More than 10 leaves can not be approved for Accounts");
            }
            return base.ApproveLeaves(p_leavesdays);
        }
    }
}
