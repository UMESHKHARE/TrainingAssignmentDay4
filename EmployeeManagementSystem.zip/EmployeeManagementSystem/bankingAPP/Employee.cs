﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingAPP
{
    internal abstract class Employee
    {
        #region Static 
        static int auto_employeeid = 1; //static int are by default 0

        #endregion

        #region Variables

        int v_empID;
        string v_empName;
        string v_empType;
        double v_empSalary;
        double v_leaveBalance;
        bool v_empIsActive;

        #endregion

        #region Properties

        public int EmployeeId
        {
            get
            {
                return v_empID;
            }
            set
            {
                v_empID = value;
            }
        }

        public string EmployeeName
        {
            get
            {
                return v_empName;
            }
            set
            {
                v_empName = value;
            }
        }

        public string EmployeeType
        {
            get
            {
                return v_empType;
            }
            set
            {
                v_empType = value;
            }
        }

        public double EmployeeSalary
        {
            get
            {
                return v_empSalary;
            }
            set
            {
                v_empSalary = value;
            }
        }
        public double LeaveBalance
        {
            get
            {
                return v_leaveBalance;
            }
            set
            {
                v_leaveBalance = value;
            }
        }

        public bool EmployeeIsActive
        {
            get
            {
                return v_empIsActive;
            }
            set
            {
                v_empIsActive = value;
            }
        }
        #endregion

        #region Methods
        

        public virtual double ApproveLeaves(int p_leavesdays)
        {
            LeaveBalance = LeaveBalance - p_leavesdays;
            return LeaveBalance;
        }

       

        #endregion

        #region Constructor

        public Employee(string p_name, string p_type,double p_salary, double p_leavebalance)
        {
            EmployeeName = p_name;
            EmployeeType = p_type;
            EmployeeSalary = p_salary;
            auto_employeeid = auto_employeeid + 1;
            EmployeeId = auto_employeeid;
        }
        #endregion

    }
}
